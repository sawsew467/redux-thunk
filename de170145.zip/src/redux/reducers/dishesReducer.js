const initialState = {
    initialState: [],
  };
  
  const dishesReducer = (state = initialState, action) => {
    switch (action.type) {
      default:
        return state;
    }
  };
  
  export default dishesReducer;
  